package net.guides.springboot2.springboot2swagger2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot2Swagger2Application {

	public static void main(String[] args) {
		SpringApplication.run(Springboot2Swagger2Application.class, args);
	}
}
