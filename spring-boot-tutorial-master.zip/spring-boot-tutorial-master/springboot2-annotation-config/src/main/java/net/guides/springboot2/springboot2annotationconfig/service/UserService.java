package net.guides.springboot2.springboot2annotationconfig.service;

public interface UserService {
	public void processMsg(String message);
}
